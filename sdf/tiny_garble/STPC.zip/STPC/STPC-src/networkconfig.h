#ifndef NETWORKCONFIG_H
#define NETWORKCONFIG_H

#include <QDialog>

namespace Ui {
class networkConfig;
}

class networkConfig : public QDialog
{
    Q_OBJECT

public:
    explicit networkConfig(QWidget *parent = nullptr);
    ~networkConfig();

private:
    Ui::networkConfig *ui;
};

#endif // NETWORKCONFIG_H
