#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QObject>
#include <QDebug>
#include <QTcpServer>
#include <QTcpSocket>
#include <QQueue>

class TcpServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit TcpServer(QObject *parent = nullptr, QString path = nullptr);
    void closeServer();
    bool openServer(quint16 port);

signals:

public slots:
    void newConnection();
    void getRequest();
    void writeTcp(QTcpSocket *, char *);
    QString readTcp(QTcpSocket *);
    void finishRequest();

private:
    QString path;
    QString currentKey = "";
    QQueue<QPair<QTcpSocket *, uint>> queue;
    bool busy;
    void giveKey();
};

#endif // TCPSERVER_H
