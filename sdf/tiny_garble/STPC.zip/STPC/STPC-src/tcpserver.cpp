#include "tcpserver.h"

TcpServer::TcpServer(QObject *parent) : QTcpServer(parent),
    serverUp(false)
{

}

bool TcpServer::openServer(quint16 port)
{
    connect(this, SIGNAL(newConnection()), this, SLOT(newConnection()));
    if(!this->listen(QHostAddress::Any, port)) {
        qDebug() << "Server could not start";
    } else {
        qDebug() << "Server started";
        serverUp = true;
    }
    return serverUp;
}


void TcpServer::newConnection()
{
    socket = this->nextPendingConnection();
    qDebug() << "New connection";
}

void TcpServer::closeServer() {
    if(serverUp) {
        qDebug() << "Closing Server";
        socket->close();
        this->close();
    }
}

QTcpSocket* TcpServer::getSocket()
{
    return socket;
}
