#include "tcpserver.h"
#include <fstream>
#include <iostream>
#include <QDir>
#include <QThread>

TcpServer::TcpServer(QObject *parent, QString path) :
  QTcpServer(parent),
  path(path),
  busy(false)
{

}

bool TcpServer::openServer(quint16 port)
{
    connect(this, SIGNAL(newConnection()), this, SLOT(newConnection()));
    if(!this->listen(QHostAddress::Any, port)) {
        qDebug() << "Server could not start";
        return false;
    } else {
        qDebug() << "Server started";
        return true;
    }
}


void TcpServer::newConnection()
{
    QTcpSocket *tmp = this->nextPendingConnection();
    connect(tmp, SIGNAL(readyRead()), this, SLOT(getRequest()));
    connect(tmp, SIGNAL(disconnected()), this, SLOT(finishRequest()));
    qDebug() << "New connection";
}

void TcpServer::getRequest() {

    QTcpSocket *socket = (QTcpSocket *)sender();
    QString message = readTcp(socket);

    bool ok;
    int size = message.toInt(&ok);
    if(ok) {
        qDebug() << "Size read sucessfully:" << size;
    } else {
        qDebug() << "Failed to read the string";
    }

    queue.enqueue(qMakePair(socket, size));
    if(!busy) {
        busy = true;
        giveKey();
    }
}

void TcpServer::giveKey() {

    QPair<QTcpSocket *, uint> tmp = queue.dequeue();
    int size = tmp.second;

    QFile f(path);
    QString key;
    if(f.open(QIODevice::ReadWrite | QIODevice::Text))
    {
       QString line;
       QTextStream t(&f);
       line = t.readLine();
       f.resize(0);
       t << line.right(line.length() - size);
       f.close();
       key = line.left(size);
    }

    writeTcp(tmp.first, key.toLocal8Bit().data());
    qDebug() << "Key sent!";

    tmp.first->close();

}

void TcpServer::finishRequest() {
    if(queue.size() != 0)
        giveKey();
    else
        busy = false;
}

void TcpServer::writeTcp(QTcpSocket *socket, char* message) {
    socket->write(message, strlen(message));
    socket->flush();
}

QString TcpServer::readTcp(QTcpSocket *socket) {
    QString message = socket->readAll();
    return message;
}

void TcpServer::closeServer() {
    qDebug() << "Closing Server";
    while(queue.size() > 0)
        queue.dequeue().first->close();
    this->close();
}
