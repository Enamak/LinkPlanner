/home/enamak/TinyGarble/bin/garbled_circuit/TinyGarble --bob --scd_file /home/enamak/circuits/moda/moda.scd -s 127.0.0.1 -p 1234 --input 00000000
