#include <QCoreApplication>
#include "tcpserver.h"
#include <QDebug>
#include <QFile>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    if(argc < 3) {
        qDebug() << "Usage: ./key_server [pathToKeyFile] [PORT]";
        exit(EXIT_FAILURE);
    }

    qDebug() << argv[1];

    QFile file(argv[1]);
    if(!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Invalid file path";
        exit(EXIT_FAILURE);
    }

    QRegExp regexPort("^(102[4-9]|10[3-9]\\d|1[1-9]\\d{2}|[2-9]\\d{3}|[1-5]\\d{4}|6[0-4]\\d{3}|65[0-4]\\d{2}|655[0-2]\\d|6553[0-5])$");
    QString port = QString::fromStdString(argv[2]);
    if(!regexPort.exactMatch(port)) {
        qDebug() << "Port has to be between 1024 and 65535";
        exit(EXIT_FAILURE);
    }

    TcpServer *tcpServer = new TcpServer(nullptr, argv[1]);
    tcpServer->openServer(quint16(port.toInt()));

    return a.exec();
}
