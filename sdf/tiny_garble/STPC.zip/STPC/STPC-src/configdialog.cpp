#include "configdialog.h"
#include "ui_configdialog.h"
#include <QDebug>
#include <QRegExpValidator>
#include <QPoint>

ConfigDialog::ConfigDialog(QWidget *parent, QString host) :
    QDialog(parent),
    ui(new Ui::ConfigDialog),
    validTgIp(false),
    validKeyIp(false),
    validTgPort(false),
    validKeyPort(false)
{
    ui->setupUi(this);
    setWindowTitle("Network Configuration");
    int width = 400;
    int height = 240;
    setFixedSize(width, height);
    setWindowFlags(((this->windowFlags() | Qt::CustomizeWindowHint) & ~Qt::WindowCloseButtonHint));

    QRegExp rexeg("([0-9]{1,3}\\.){0,3}[0-9]{0,3}");
    QRegExpValidator *validatorIp = new QRegExpValidator(rexeg);
    ui->tgIpInput->setValidator(validatorIp);
    ui->keyIpInput->setValidator(validatorIp);

    QRegExp portRexeg("^[0-9]{0,5}");
    QRegExpValidator *validatorPort = new QRegExpValidator(portRexeg);
    ui->tgPortInput->setValidator(validatorPort);
    ui->keyPortInput->setValidator(validatorPort);

    if(host == "Alice") {
        isAlice = true;
        validTgIp = true;
        setFixedSize(400, 240);
        ui->buttonBox_2->move(QPoint(ui->buttonBox_2->pos().rx(), 200));
        ui->tgIpInput->setText("127.0.0.1");
        ui->tgIpInput->setReadOnly(true);
    } else {
        validKeyIp = true;
        validKeyPort = true;
        ui->frame_3->hide();
        ui->buttonBox_2->move(QPoint(ui->buttonBox_2->pos().rx(), 100));
        setFixedSize(400, 140);
        ui->tgIpInput->setReadOnly(false);
    }

}

ConfigDialog::~ConfigDialog()
{
    delete ui;
}

void ConfigDialog::on_buttonBox_2_accepted()
{

    bool run = true;

    if(!validTgIp) {
        ui->tgWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->tgWarning->setText("Insert Alice's IP Adress!");
        run = false;
    } else if(!validTgPort) {
        ui->tgWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->tgWarning->setText("Insert a valid PORT for the connection!");
        run = false;
    }

    if(!validKeyIp) {
        ui->keyWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->keyWarning->setText("Insert Key provider IP Adress");
        run = false;
    } else if(!validKeyPort) {
        ui->keyWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->keyWarning->setText("Insert a valid PORT for the connection!");
        run = false;
    }

    if(run) {
        this->accept();
    }
}

void ConfigDialog::on_buttonBox_2_rejected()
{
    this->reject();
}

QString ConfigDialog::getTgIp()
{
    return ui->tgIpInput->text();
}
QString ConfigDialog::getTgPort()
{
    return ui->tgPortInput->text();
}
QString ConfigDialog::getKeyIp()
{
    return ui->keyIpInput->text();
}
QString ConfigDialog::getKeyPort()
{
    return ui->keyPortInput->text();
}

void ConfigDialog::on_tgIpInput_textEdited(const QString &arg1)
{
    QRegExp rexegIp("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
    if(!isAlice && !rexegIp.exactMatch(ui->tgIpInput->text())) {
        ui->tgWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->tgWarning->setText("Insert a valid IP Adress!");
        validTgIp = false;
    } else {
        validTgIp = true;
        on_tgPortInput_textEdited("");
    }
}

void ConfigDialog::on_tgPortInput_textEdited(const QString &arg1)
{
    QRegExp regexPort("^(102[4-9]|10[3-9]\\d|1[1-9]\\d{2}|[2-9]\\d{3}|[1-5]\\d{4}|6[0-4]\\d{3}|65[0-4]\\d{2}|655[0-2]\\d|6553[0-5])$");

    ui->tgWarning->setStyleSheet("color: rgb(204, 0, 0);");
    if(!regexPort.exactMatch(ui->tgPortInput->text())) {
        ui->tgWarning->setText("Port has to be between 1024 and 65535!");
        validTgPort = false;
    } else {
        validTgPort = true;
        int port = ui->tgPortInput->text().toInt();
        port = port + (port == 65535 ? -1 : 1);
        if(validTgIp) {
            ui->tgWarning->setStyleSheet("color: rgb(32, 74, 135);");
            ui->tgWarning->setText("The Port " + QString::number(port) + " will be used for the Interface connection");
           if(isAlice && ui->keyPortInput->text() != "") on_keyPortInput_textEdited(""); // Only checks if key port is using the same in case of Alice
        }
        else ui->tgWarning->setText("Insert a valid IP Adress!");
    }
}

void ConfigDialog::on_keyIpInput_textEdited(const QString &arg1)
{
    QRegExp rexegIp("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
    if(!rexegIp.exactMatch(ui->keyIpInput->text())) {
        ui->keyWarning->setStyleSheet("color: rgb(204, 0, 0);");
        ui->keyWarning->setText("Insert a valid IP Adress!");
        validKeyIp = false;
    } else {
        validKeyIp = true;
        on_keyPortInput_textEdited("");
    }
}

void ConfigDialog::on_keyPortInput_textEdited(const QString &arg1)
{
    QRegExp regexPort("^(102[4-9]|10[3-9]\\d|1[1-9]\\d{2}|[2-9]\\d{3}|[1-5]\\d{4}|6[0-4]\\d{3}|65[0-4]\\d{2}|655[0-2]\\d|6553[0-5])$");

    validKeyPort = false;
    ui->keyWarning->setStyleSheet("color: rgb(204, 0, 0);");
    if(!regexPort.exactMatch(ui->keyPortInput->text())) {
        ui->keyWarning->setText("Port has to be between 1024 and 65535!");
    } else {
        int port = ui->tgPortInput->text().toInt();
        port = port + (port == 65535 ? -1 : 1);
        QString newPort = QString::number(port);
        if(ui->keyPortInput->text() == ui->tgPortInput->text() || ui->keyPortInput->text() == newPort) {
            ui->keyWarning->setText("Port already in use!");
        } else {
            validKeyPort = true;
            if(validKeyIp) {
                ui->keyWarning->setStyleSheet("color: rgb(32, 74, 135);");
                ui->keyWarning->setText("The IP address " + ui->keyIpInput->text() + ":" + ui->keyPortInput->text() + " is valid.");
            }
            else ui->keyWarning->setText("Insert a valid IP Adress!");
        }
    }
}

void ConfigDialog::on_buttonBox_2_clicked(QAbstractButton *button)
{

}
